# 六甲保胎符 · 内密

道教符箓教学页（第一符）。纯黑白，符体取原符抠图，悬停 / 点选各部位显现内密与画法，所指分支墨迹转朱。

## 部署（GitHub Pages）

1. 新建仓库，将本目录所有文件（含 `.nojekyll`）上传到仓库根目录；
2. 仓库 Settings → Pages → Source 选 `main` 分支 `/ (root)`，保存；
3. 稍候访问 `https://<用户名>.github.io/<仓库名>/` 即可。

手机端访问：点选分区即固定显示内密，再点同区取消，点他区切换；所指分支符体转朱。

## 文件

- `index.html` — 页面本体
- `fu.png` — 符体原图（黄纸条抠图，纯黑白）
- `g_jue.png / g_he.png / g_yj.png / g_yh.png / g_hz.png` — 复合字与花字原墨抠图
- `.nojekyll` — 跳过 GitHub Pages 的 Jekyll 处理
